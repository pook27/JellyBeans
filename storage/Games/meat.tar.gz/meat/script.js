// --- CONFIGURATION ---
const startDate = new Date(2026, 2, 20); // March 20, 2026 (Month is 0-indexed)

// Estimates based on replacing meat/dairy per day
const dailyImpact = {
    money: 3.00,       // $3 saved per day
    water: 500,        // Gallons of water saved
    co2: 10,           // Lbs of CO2 emissions avoided
    forest: 15         // Sq ft of forest preserved
};

const badges = [
    { threshold: 1, name: "The First Step", icon: "🌱", desc: "1 Day Meat-Free" },
    { threshold: 7, name: "Rooted", icon: "🌿", desc: "1 Week Complete" },
    { threshold: 30, name: "Blossoming", icon: "🌻", desc: "1 Month Milestone" },
    { threshold: 100, name: "Thriving", icon: "🌳", desc: "100 Days Strong" },
    { threshold: 365, name: "Earth Guardian", icon: "🌍", desc: "1 Year Anniversary" }
];

const facts = [
    "Eating a plant-based diet is one of the most effective ways to lower your carbon footprint.",
    "It takes about 1,800 gallons of water to produce a single pound of beef. Lentils require only a fraction of that!",
    "Plant-based diets are rich in fiber, which feeds the good bacteria in your gut and improves digestion.",
    "Switching out dairy milk for oat or almond milk significantly reduces land and water usage.",
    "A vegetarian diet can lower the risk of heart disease by up to 32%.",
    "Pigs and cows are highly social and intelligent animals. By going meat-free, you are promoting compassion.",
    "Legumes and beans are incredible sources of protein and actually restore nitrogen to the soil as they grow."
];

// --- THEME SWITCHER ---
function setTheme(themeName) {
    document.body.className = themeName;
    localStorage.setItem('plant_theme', themeName);
}

// --- PRODUCTIVITY TRACKER ---
function setDailyGoal() {
    const input = document.getElementById('dailyGoalInput');
    const goal = input.value.trim();
    if (goal) {
        localStorage.setItem('plant_daily_goal', goal);
        localStorage.setItem('plant_goal_date', new Date().toDateString());
        localStorage.setItem('plant_goal_done', 'false');
        renderGoal(goal, false);
    }
}

function renderGoal(goal, isDone) {
    document.querySelector('.productivity-input-group').style.display = 'none';
    const display = document.getElementById('dailyGoalDisplay');
    display.style.display = 'block';
    
    const icon = document.getElementById('goalCheckIcon');
    const text = document.getElementById('goalText');
    
    text.innerText = goal;
    if (isDone) {
        icon.className = 'fa-regular fa-square-check';
        text.style.textDecoration = 'line-through';
        text.style.opacity = '0.6';
    } else {
        icon.className = 'fa-regular fa-square';
        text.style.textDecoration = 'none';
        text.style.opacity = '1';
    }
}

function toggleGoalComplete() {
    const current = localStorage.getItem('plant_goal_done') === 'true';
    localStorage.setItem('plant_goal_done', (!current).toString());
    renderGoal(localStorage.getItem('plant_daily_goal'), !current);
}

function resetDailyGoal() {
    localStorage.removeItem('plant_daily_goal');
    document.getElementById('dailyGoalInput').value = '';
    document.querySelector('.productivity-input-group').style.display = 'flex';
    document.getElementById('dailyGoalDisplay').style.display = 'none';
}

function checkDailyGoal() {
    const savedDate = localStorage.getItem('plant_goal_date');
    const today = new Date().toDateString();
    
    if (savedDate !== today) {
        resetDailyGoal(); 
    } else {
        const goal = localStorage.getItem('plant_daily_goal');
        if (goal) {
            const isDone = localStorage.getItem('plant_goal_done') === 'true';
            renderGoal(goal, isDone);
        }
    }
}

// --- WIDGETS ---
function updateFunFact() {
    const factElement = document.getElementById('randomFact');
    const refreshBtn = document.querySelector('.refresh-btn');
    
    if(refreshBtn) {
        refreshBtn.classList.add('fa-spin');
        setTimeout(() => refreshBtn.classList.remove('fa-spin'), 500);
    }
    
    const randomFact = facts[Math.floor(Math.random() * facts.length)];
    factElement.innerText = randomFact;
}

function updateDailyQuote() {
    // A curated list of encouraging quotes
    const quotes = [
        { text: "Every time you eat is an opportunity to nourish your body and the planet.", author: "Unknown" },
        { text: "Small acts, when multiplied by millions of people, can transform the world.", author: "Howard Zinn" },
        { text: "The food you eat can be either the safest and most powerful form of medicine.", author: "Ann Wigmore" },
        { text: "You don't have to be perfect. Just try to do a little better every day.", author: "Unknown" }
    ];
    
    const q = quotes[new Date().getDate() % quotes.length];
    document.getElementById('dailyQuote').innerText = `"${q.text}"`;
    document.getElementById('quoteAuthor').innerText = `- ${q.author}`;
}

// --- PARTICLES ANIMATION ---
function initParticles() {
    const canvas = document.getElementById('particleCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let particles = [];
    const particleCount = 40;

    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 3 + 1;
            this.speedX = Math.random() * 1 - 0.5;
            this.speedY = (Math.random() * -1) - 0.2; // Float upwards like bubbles/spores
            this.opacity = Math.random() * 0.5 + 0.1;
        }
        update() {
            this.x += this.speedX;
            this.y += this.speedY;
            if (this.y < 0) {
                this.y = canvas.height;
                this.x = Math.random() * canvas.width;
            }
        }
        draw() {
            ctx.fillStyle = `rgba(255, 255, 255, ${this.opacity})`;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    for (let i = 0; i < particleCount; i++) particles.push(new Particle());

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => { p.update(); p.draw(); });
        requestAnimationFrame(animate);
    }
    animate();

    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}

// --- CORE FUNCTIONS ---

function renderBadges(daysActive) {
    const container = document.getElementById('badgesGrid');
    container.innerHTML = badges.map(badge => {
        const isUnlocked = daysActive >= badge.threshold;
        const statusClass = isUnlocked ? 'unlocked' : 'locked';
        return `
            <div class="badge-card ${statusClass}">
                <div class="badge-icon">${badge.icon}</div>
                <div class="badge-name">${badge.name}</div>
                <div class="badge-desc">${badge.desc}</div>
            </div>
        `;
    }).join('');
}

function updateImpactStats(elapsedDays) {
    // Only calculate full days for impact to not exaggerate
    const days = Math.floor(elapsedDays);
    
    const data = [
        { icon: "💰", val: "$" + (days * dailyImpact.money).toFixed(2), text: "Money Saved" },
        { icon: "💧", val: (days * dailyImpact.water).toLocaleString(), text: "Gallons of Water Saved" },
        { icon: "☁️", val: (days * dailyImpact.co2).toLocaleString(), text: "Lbs CO2 Avoided" },
        { icon: "🌳", val: (days * dailyImpact.forest).toLocaleString(), text: "Sq ft Forest Saved" }
    ];

    document.getElementById('impactGrid').innerHTML = data.map(item => `
        <div class="fun-card">
            <span class="fun-icon">${item.icon}</span>
            <div class="fun-number">${item.val}</div>
            <div style="font-size: 0.9em">${item.text}</div>
        </div>
    `).join('');
}

function getNextMilestone(daysActive) {
    if (daysActive < 7) return 7;
    if (daysActive < 30) return 30;
    if (daysActive < 100) return 100;
    if (daysActive < 365) return 365;
    return Math.ceil((daysActive + 1) / 365) * 365; // Next year
}

function updateCountup() {
    const now = new Date();
    const elapsed = now - startDate;
    
    // If we are before the start date somehow
    if (elapsed < 0) {
        document.getElementById('timeElapsedMsg').innerText = "Your journey hasn't started yet! Waiting for March 20, 2026.";
        return;
    }

    const elapsedDaysFloat = elapsed / 86400000;
    const days = Math.floor(elapsed / 86400000);
    const hours = Math.floor((elapsed % 86400000) / 3600000);
    const minutes = Math.floor((elapsed % 3600000) / 60000);
    const seconds = Math.floor((elapsed % 60000) / 1000);

    document.getElementById('timeElapsedMsg').innerText = `You've been meat-free for ${days} days!`;
    document.getElementById('streakCount').innerText = days; // Using absolute days as streak

    const counters = [
        { number: days, label: '📅 Days' },
        { number: hours, label: '⏰ Hours' },
        { number: minutes, label: '⏱️ Minutes' },
        { number: seconds, label: '⚡ Seconds' },
    ];

    document.getElementById('countdownGrid').innerHTML = counters.map(item => `
        <div class="countdown-card">
            <div class="countdown-number">${item.number}</div>
            <div class="countdown-label">${item.label}</div>
        </div>
    `).join('');

    // 1. Progress Ring (Progress to Next Milestone)
    const circle = document.getElementById('progressRing');
    if (circle) {
        const nextMilestone = getNextMilestone(days);
        // Calculate base of last milestone to make the circle visually fill up for the CURRENT stage
        let lastMilestone = 0;
        if(nextMilestone == 7) lastMilestone = 0;
        else if(nextMilestone == 30) lastMilestone = 7;
        else if(nextMilestone == 100) lastMilestone = 30;
        else if(nextMilestone == 365) lastMilestone = 100;

        const currentStageDuration = nextMilestone - lastMilestone;
        const progressInStage = days - lastMilestone;
        const percentDone = Math.min(100, Math.max(0, (progressInStage / currentStageDuration) * 100));

        const radius = circle.r.baseVal.value;
        const circumference = radius * 2 * Math.PI;
        
        const offset = circumference - (percentDone / 100 * circumference);
        circle.style.strokeDashoffset = offset;
        
        document.getElementById('percentageText').innerText = percentDone.toFixed(0) + '%';
        document.getElementById('nextMilestoneText').innerText = `Heading towards your ${nextMilestone} Day Milestone!`;
        
        // 2. Thermometer Widget (Visual health indicator based on overall days up to 1 year)
        const healthPercent = Math.min(100, (days / 365) * 100);
        const thermo = document.getElementById('thermometerFill');
        if(thermo) thermo.style.height = Math.max(10, healthPercent) + '%'; 
    }

    renderBadges(days);
    updateImpactStats(elapsedDaysFloat);
}

window.onload = () => {
    const savedTheme = localStorage.getItem('plant_theme');
    if (savedTheme) document.body.className = savedTheme;

    updateDailyQuote();
    initParticles();
    checkDailyGoal();
    updateFunFact();
    
    updateCountup();
    setInterval(updateCountup, 1000);
};
